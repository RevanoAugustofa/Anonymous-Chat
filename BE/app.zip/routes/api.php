<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\PromptController;
use App\Http\Controllers\Api\ResponseController;
use App\Http\Controllers\AuthController;
use App\Http\Middleware\CorsMiddleware;
Route::post('/register', [AuthController::class, 'register']);

// Route::middleware([CorsMiddleware::class])->group(function () {



//     // ✅ PROTECTED USER ROUTE - Get user after login
//     // Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     //     return $request->user();
//     // });


//     // ✅ USER ENDPOINTS
//     Route::prefix('users')->group(function () {
//         Route::get('/', [UserController::class, 'index']);
//         Route::post('/', [UserController::class, 'store']);
//         Route::get('{kode_unik}', [UserController::class, 'show']);

//         // PROMPTS by user
//         Route::get('{kode_unik}/prompts', [PromptController::class, 'index']);
//         Route::post('{kode_unik}/prompts', [PromptController::class, 'store']);
//     });

//     // ✅ PROMPT ENDPOINTS
//     Route::prefix('prompts')->group(function () {
//         Route::delete('{kode_unik}/{prompt_id}', [PromptController::class, 'destroy']);

//         // RESPONSES
//         Route::post('{prompt_id}/responses', [ResponseController::class, 'store']);
//         Route::get('{prompt_id}/responses', [ResponseController::class, 'index']);
//     });

//     // ✅ TESTING ENDPOINT
//     Route::get('/ping', function () {
//         return response()->json(['message' => 'pong']);
//     });


// });


