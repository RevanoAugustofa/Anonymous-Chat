<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;



// Route::middleware(['web'])->group(function () {
//     Route::post('/login', [AuthController::class, 'login']);
//     Route::get('/test-cookie', function () {
//         return response()->json(['msg' => 'hello'])->cookie('test', 'ok', 60);
//     });
// });

// Route::middleware('web')->post('/test-session', function (){
//     return session()->all();
// });

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

// Group middleware web Wajib
Route::middleware(['web'])->group(function () {
    // Route::get('/sanctum/csrf-cookie', function () {
    //     return response()->json(['csrf' => true]);
    // });

    Route::post('/login', [AuthController::class, 'login']);
    // Route::post('/register', [AuthController::class, 'register']);

});

Route::middleware(['web', 'auth:sanctum'])->get('/user', function (Request $request) {
    return $request->user();
});


// use Illuminate\Http\Request;
// Route::post('/login', function (Request $request) {
//     Log::info('Login hit!');
//     Log::info('XSRF Header: ' . $request->header('X-XSRF-TOKEN'));
//     Log::info('Has session: ' . (bool) $request->cookie(config('session.cookie')));
//     return 'ok';
// });
