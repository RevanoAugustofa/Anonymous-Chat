<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

use Illuminate\Support\Facades\Log;

class VerifyCsrfToken extends Middleware
{
    protected $addHttpCookie = true;

    protected $except = [
        'api/*',
    ];

protected function tokensMatch($request)
{
    $headerToken = $request->header('X-XSRF-TOKEN');
    $sessionToken = $request->session()->token();
    $cookieToken = $request->cookie('XSRF-TOKEN');

    Log::info('=== CSRF DEBUG ===');
    Log::info('Header XSRF-TOKEN: ' . $headerToken);
    Log::info('Session Token: ' . $sessionToken);
    Log::info('Cookie XSRF-TOKEN: ' . $cookieToken);
    Log::info('Semua Cookies: ', $request->cookies->all());
    Log::info('==================');

    return parent::tokensMatch($request);
}

}
